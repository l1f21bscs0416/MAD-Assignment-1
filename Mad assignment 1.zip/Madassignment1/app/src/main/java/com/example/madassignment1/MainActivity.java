package com.example.madassignment1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.lang.Math;

public class MainActivity extends AppCompatActivity {

    EditText input;
    String expression = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.input);

        findViewById(R.id.btn1).setOnClickListener(v -> appendValue("1"));
        findViewById(R.id.btnAdd).setOnClickListener(v -> appendValue("+"));
        findViewById(R.id.btnEqual).setOnClickListener(v -> calculate());
    }

    void appendValue(String val) {
        expression += val;
        input.setText(expression);
    }

    void calculate() {
        try {
            double result = eval(expression);
            input.setText(String.valueOf(result));
        } catch (Exception e) {
            input.setText("Error");
        }
    }

    double eval(String exp) {
        return Double.valueOf(exp);
    }
}
